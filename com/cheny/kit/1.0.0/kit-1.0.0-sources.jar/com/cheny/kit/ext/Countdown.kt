package com.cheny.kit.ext

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive

fun Long.countdown(step: Long = 1_000L): Flow<Long> = flow {
    require(step > 0) { "step must be > 0" }

    var remain = this@countdown.coerceAtLeast(0L)

    while (remain > 0 && currentCoroutineContext().isActive) {
        emit(remain)

        val next = (remain - step).coerceAtLeast(0L)
        delay(remain - next)

        remain = next
    }

    emit(0L)
}

fun Int.countdown(step: Long = 1_000): Flow<Long> = toLong().countdown(step)