package com.cheny.kit.ext

import android.os.Looper

val isMainThread: Boolean
    get() = Looper.myLooper() == Looper.getMainLooper()

@Suppress("UNCHECKED_CAST")
fun <T> Any.cast(): T = this as T

@Suppress("UNCHECKED_CAST")
fun <T> Any?.castOrNull(): T? = runCatching { this as T }.getOrNull()

fun <T, M> T?.mapperOrNull(predicate: (T) -> M): M? {
    return if (this != null) predicate(this) else null
}

fun <T, M> T.mapper(predicate: (T) -> M): M {
    return predicate(this)
}
