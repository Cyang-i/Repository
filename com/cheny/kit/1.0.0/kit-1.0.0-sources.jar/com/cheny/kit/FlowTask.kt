package com.cheny.kit

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/**
 * Flow任务流管理器
 * @author: Cy
 * @date: 2026-04-11 18:18
 */
class FlowTask(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    private val queue = ArrayDeque<TaskHandle>()
    private val mutex = Mutex()
    private val signal = Channel<Unit>(Channel.CONFLATED)

    //当前正在运行的任务
    private var currentHandle: TaskHandle? = null
    private var currentJob: Job? = null

    init {
        scope.launch {
            while (isActive) {
                val handle = mutex.withLock {
                    if (queue.isNotEmpty()) queue.removeFirst() else null
                }

                if (handle != null) {
                    val taskJob = launch {
                        try {
                            handle.task()
                        } catch (_: CancellationException) {
                            // 任务取消
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    mutex.withLock {
                        currentHandle = handle
                        currentJob = taskJob
                    }

                    taskJob.join()

                    mutex.withLock {
                        currentHandle = null
                        currentJob = null
                    }
                } else {
                    signal.receive()
                }
            }
        }
    }

    /**
     * 提交普通任务
     * @param key 任务唯一标识
     * @param replaceRunning 如果该 Key 的任务正在运行，是否中断并替换
     */
    fun post(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(key, isFirst = false, replaceRunning = replaceRunning, block = block)

    /**
     * 提交高优先级任务（插入队首）
     */
    fun postFirst(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(key, isFirst = true, replaceRunning = replaceRunning, block = block)

    /**
     * 提交异步任务（需手动调用 taskDone）
     */
    fun postAsync(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        block: suspend TaskScope.() -> Unit
    ): String = wrapAndEnqueue(
        key, isFirst = false, isAsync = true, replaceRunning = replaceRunning, asyncBlock = block
    )

    private fun wrapAndEnqueue(
        key: String,
        isFirst: Boolean,
        isAsync: Boolean = false,
        replaceRunning: Boolean = false,
        block: (suspend () -> Unit)? = null,
        asyncBlock: (suspend TaskScope.() -> Unit)? = null
    ): String {
        val taskLogic: suspend () -> Unit = {
            if (isAsync) {
                val deferred = CompletableDeferred<Unit>()
                val taskScope = object : TaskScope {
                    override fun taskDone() {
                        if (deferred.isActive) deferred.complete(Unit)
                    }
                }
                asyncBlock?.invoke(taskScope)
                deferred.await()
            } else {
                block?.invoke()
            }
        }

        val newHandle = TaskHandle(key, taskLogic)

        scope.launch {
            mutex.withLock {
                //检查是否正在运行
                if (currentHandle?.key == key) {
                    if (replaceRunning) {
                        currentJob?.cancel()
                        queue.addFirst(newHandle)
                    }
                    //如果replaceRunning为false忽略任务
                } else {
                    //检查是否在队列中排队，如果是则替换
                    val indexInQueue = queue.indexOfFirst { it.key == key }
                    if (indexInQueue != -1) {
                        queue.removeAt(indexInQueue)
                    }
                    if (isFirst) queue.addFirst(newHandle) else queue.addLast(newHandle)
                }
            }
            signal.trySend(Unit)
        }
        return key
    }

    suspend fun hasTask(key: String): Boolean = mutex.withLock {
        !getAllTask().find { it == key }.isNullOrEmpty()
    }

    suspend fun isTaskRunning(key: String): Boolean = mutex.withLock { currentHandle?.key == key }

    suspend fun getAllTask(): List<String> = mutex.withLock {
        val keys = mutableListOf<String>()
        currentHandle?.let { keys.add(it.key) }
        keys.addAll(queue.map { it.key })
        keys
    }

    suspend fun getRunningTask(): String? = mutex.withLock { currentHandle?.key }

    /**
     * 移除任务
     * @param key 任务标识
     * @param cancelIfRunning 如果任务正在运行，是否取消
     */
    suspend fun remove(key: String, cancelIfRunning: Boolean = true) {
        mutex.withLock {
            if (currentHandle?.key == key) {
                if (cancelIfRunning) {
                    currentJob?.cancel()
                    currentHandle = null
                    currentJob = null
                }
            } else {
                queue.removeAll { it.key == key }
            }
        }
    }

    fun stop() {
        signal.close()
        scope.cancel()
    }

    interface TaskScope {
        fun taskDone()
    }

    class TaskHandle(val key: String, val task: suspend () -> Unit)
}