package com.cheny.kit

import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.cheny.kit.ext.cast
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

object FlowBus {

    private val bus = ConcurrentHashMap<String, MutableSharedFlow<Any>>()

    fun <T> with(key: String, isSticky: Boolean = false): MutableSharedFlow<T> {
        return bus.getOrPut(key) {
            MutableSharedFlow<Any>(
                replay = if (isSticky) 1 else 0,
                extraBufferCapacity = 64,
                onBufferOverflow = BufferOverflow.DROP_OLDEST
            ).also { flow ->
                startAutoCleanup(key, flow)
            }
        }.cast()
    }

    /**
     * 自动清理逻辑：当订阅者数量变为 0 时，延迟移除
     */
    private fun startAutoCleanup(key: String, flow: MutableSharedFlow<Any>) {
        ProcessLifecycleOwner.get().lifecycleScope.launch {
            flow.subscriptionCount
                .map { it == 0 }
                .distinctUntilChanged()
                .collectLatest { isEmpty ->
                    if (isEmpty) {
                        delay(5000)
                        if (flow.subscriptionCount.value == 0) {
                            bus.remove(key)
                        }
                    }
                }
        }
    }

    inline fun <reified T : Any> post(event: T, isSticky: Boolean = false) {
        with<T>(T::class.java.name, isSticky).tryEmit(event)
    }

    inline fun <reified T : Any> with(isSticky: Boolean = false): MutableSharedFlow<T> {
        return with(T::class.java.name, isSticky)
    }
}