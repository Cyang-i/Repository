package com.cheny.kit.utils

import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 用于常见编码操作的工具。
 *
 * 提供以下简化的加密：
 * - **Base64**：字符串和字节数组的编码与解码。
 * - **哈希**：MD5和SHA-1消息摘要。
 * - **对称加密**：AES加密（默认为CBC/PKCS5Padding）。
 * - **非对称加密**：使用公钥/私钥生成和加密 RSA 密钥对。
 *
 * @author MasterChan
 * @date 2026-04-06 21:33
 */
object Encryptor {

    fun base64(input: ByteArray, flags: Int = Base64.NO_WRAP): ByteArray {
        return Base64.encode(input, flags)
    }

    fun base64(input: String, flags: Int = Base64.NO_WRAP): ByteArray {
        return base64(input.toByteArray(), flags)
    }

    fun base64String(input: ByteArray, flags: Int = Base64.NO_WRAP): String {
        return Base64.encodeToString(input, flags)
    }

    fun base64String(input: String, flags: Int = Base64.NO_WRAP): String {
        return Base64.encodeToString(input.toByteArray(), flags)
    }

    fun md5(input: String): String {
        return md5(input.toByteArray()).toHexString()
    }

    fun md5(input: ByteArray): ByteArray {
        return MessageDigest.getInstance("MD5").digest(input)
    }

    fun aes(
        transformation: String = "AES/CBC/PKCS5Padding",
        iv: ByteArray = "0102030405060708".toByteArray(),
        key: ByteArray,
        data: ByteArray,
    ): String {
        return encodeCipher(
            transformation,
            SecretKeySpec(key, "AES"),
            IvParameterSpec(iv),
            data
        ).toHexString()
    }

    fun encodeCipher(
        transformation: String,
        keySpec: SecretKeySpec,
        ivSpec: IvParameterSpec?,
        data: ByteArray
    ): ByteArray {
        val cipher = Cipher.getInstance(transformation)
        if (ivSpec == null) {
            cipher.init(Cipher.ENCRYPT_MODE, keySpec)
        } else {
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
        }
        return cipher.doFinal(data)
    }

    fun generateRSAKeyPair(keySize: Int = 1024): KeyPair {
        return KeyPairGenerator.getInstance("RSA").apply { initialize(keySize) }.generateKeyPair()
    }

    fun getRsaPrivateKey(key: String): PrivateKey {
        return getRsaPrivateKey(key.toByteArray())
    }

    fun getRsaPrivateKey(key: ByteArray): PrivateKey {
        return KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(key))
    }

    fun getRsaPublicKey(key: String): PublicKey {
        return getRsaPublicKey(key.toByteArray())
    }

    fun getRsaPublicKey(key: ByteArray): PublicKey {
        return KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(key))
    }

    fun rsa(publicKey: PublicKey, data: ByteArray): String? {
        val cipher = Cipher.getInstance("RSA")
        cipher.init(Cipher.ENCRYPT_MODE, publicKey)
        return Base64.encodeToString(cipher.doFinal(data), Base64.NO_WRAP)
    }

    fun sha1(input: ByteArray): ByteArray {
        return MessageDigest.getInstance("SHA-1").digest(input)
    }

    fun sha1(input: String): String {
        return MessageDigest.getInstance("SHA-1").digest(input.toByteArray()).toHexString()
    }
}
