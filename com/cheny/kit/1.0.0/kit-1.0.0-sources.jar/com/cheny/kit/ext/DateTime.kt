package com.cheny.kit.ext

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

//####################
//LocalDate
//####################
fun LocalDate.format(pattern: String, locale: Locale = Locale.getDefault()): String {
    return format(DateTimeFormatter.ofPattern(pattern, locale))
}

fun Long.toLocalDate(): LocalDate {
    return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()
}

fun String.toLocalDate(pattern: String, locale: Locale = Locale.getDefault()): LocalDate {
    return LocalDate.parse(this, DateTimeFormatter.ofPattern(pattern, locale))
}

fun Date.toLocalDate(zoneId: ZoneId = ZoneId.systemDefault()): LocalDate {
    return toLocalDateTime(zoneId).toLocalDate()
}

fun LocalDate.toDate(zoneId: ZoneId = ZoneId.systemDefault()): Date {
    return Date.from(atStartOfDay(zoneId).toInstant())
}


//####################
//LocalTime
//####################
fun LocalTime.format(pattern: String, locale: Locale = Locale.getDefault()): String {
    return format(DateTimeFormatter.ofPattern(pattern, locale))
}

fun Long.toLocalTime(): LocalTime {
    return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalTime()
}

fun String.toLocalTime(pattern: String, locale: Locale = Locale.getDefault()): LocalTime {
    return LocalTime.parse(this, DateTimeFormatter.ofPattern(pattern, locale))
}

fun Date.toLocalTime(zoneId: ZoneId = ZoneId.systemDefault()): LocalTime {
    return toLocalDateTime(zoneId).toLocalTime()
}


//####################
//LocalDateTime
//####################
fun LocalDateTime.format(pattern: String, locale: Locale = Locale.getDefault()): String {
    return format(DateTimeFormatter.ofPattern(pattern, locale))
}

fun Long.toLocalDateTime(): LocalDateTime {
    return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDateTime()
}

fun String.toLocalDateTime(pattern: String, locale: Locale = Locale.getDefault()): LocalDateTime {
    return LocalDateTime.parse(this, DateTimeFormatter.ofPattern(pattern, locale))
}

fun Date.toLocalDateTime(zoneId: ZoneId = ZoneId.systemDefault()): LocalDateTime {
    return LocalDateTime.ofInstant(this.toInstant(), zoneId)
}

fun LocalDateTime.toDate(zoneId: ZoneId = ZoneId.systemDefault()): Date {
    return Date.from(atZone(zoneId).toInstant())
}