package com.cheny.kit.ext

import com.cheny.kit.utils.RegexPool
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

fun Number?.format(digits: Int = 2, isRound: Boolean = true): String {
    val value = this?.toDouble() ?: 0.0
    val mode = if (isRound) RoundingMode.HALF_UP else RoundingMode.DOWN
    val result = BigDecimal(value.toString())
        .setScale(digits, mode)
    //强制使用Locale.US以确保小数点始终为"."，并补齐末尾的0
    return String.format(Locale.US, "%.${digits}f", result.toDouble())
}

/**
 * 去除数字（包含小数）末尾多余的 0
 *
 * 例如：
 *
 * - "12.3400" -> "12.34"
 * - "1.0"     -> "1"
 * - "100.00"  -> "100"
 * - "100"     -> "100"
 *
 * @return 处理后的字符串，若非数字或无小数点则返回原字符串
 */
fun String?.trimTrailingZeros(): String {
    if (this == null) return ""
    if (!this.contains(".")) return this

    return this.replace(RegexPool.trailingZeros, "$1")
}

/**
 * 将数值转换为字符串后，自动去除数字末尾的 0
 */
fun Number?.trimTrailingZeros(): String = this?.toString().trimTrailingZeros()