package com.cheny.kit.network

data class NetworkInfo(
    val isConnected: Boolean = false,
    val isValidated: Boolean = false,
    val isVpn: Boolean = false,
    val type: NetworkType = NetworkType.None
)