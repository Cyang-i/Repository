package com.cheny.kit

import android.app.Application

object EaseKit {
    internal lateinit var app: Application

    fun init(app: Application) {
        this.app = app
        ActivityStack.init(app)
    }
}