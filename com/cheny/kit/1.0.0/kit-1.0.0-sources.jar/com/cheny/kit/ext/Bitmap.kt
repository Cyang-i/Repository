package com.cheny.kit.ext

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.ColorInt
import androidx.annotation.FloatRange
import androidx.annotation.IntRange
import androidx.core.graphics.createBitmap
import com.cheny.kit.EaseKit
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

fun Bitmap.toByteArray(
    format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG,
    quality: Int = 100
): ByteArray {
    return ByteArrayOutputStream().use {
        compress(format, quality, it)
        it.toByteArray()
    }
}

fun ByteArray.toBitmap(options: BitmapFactory.Options? = null): Bitmap {
    return if (options == null) {
        BitmapFactory.decodeByteArray(this, 0, size)
    } else {
        BitmapFactory.decodeByteArray(this, 0, size, options)
    }
}

fun Bitmap.scale(width: Int, height: Int): Bitmap {
    return Bitmap.createScaledBitmap(this, width, height, true)
}

fun Bitmap.scale(scaleX: Float, scaleY: Float): Bitmap {
    val matrix = Matrix()
    matrix.setScale(scaleX, scaleY)
    return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
}

fun Bitmap.clip(rect: Rect): Bitmap {
    val newRect = Rect(
        rect.left.coerceAtLeast(0),
        rect.top.coerceAtLeast(0),
        rect.right.coerceAtMost(width),
        rect.bottom.coerceAtMost(height)
    )
    return Bitmap.createBitmap(this, newRect.left, newRect.top, newRect.width(), newRect.height())
}

fun Bitmap.rotate(degrees: Float): Bitmap {
    val matrix = Matrix()
    matrix.setRotate(degrees)
    return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
}

fun Bitmap.toRound(@FloatRange(from = 0.0) borderSize: Float, @ColorInt borderColor: Int): Bitmap {
    val minSide = min(width, height)

    val left = (width - minSide) / 2
    val top = (height - minSide) / 2
    val squareBitmap = clip(Rect(left, top, left + minSide, top + minSide))

    val result = createBitmap(minSide, minSide)
    val canvas = Canvas(result)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    val rectF = RectF(0f, 0f, minSide.toFloat(), minSide.toFloat())
    if (borderSize > 0) rectF.inset(borderSize / 2f, borderSize / 2f)

    paint.shader = BitmapShader(squareBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    canvas.drawOval(rectF, paint)

    if (borderSize > 0) {
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = borderSize
        paint.color = borderColor
        canvas.drawOval(rectF, paint)
    }

    return result
}

fun Bitmap.toRoundCorner(
    radius: Float,
    @FloatRange(from = 0.0) borderSize: Float = 0f,
    @ColorInt borderColor: Int = Color.TRANSPARENT,
): Bitmap {
    return toRoundCorner(FloatArray(8) { radius }, borderSize, borderColor)
}

fun Bitmap.toRoundCorner(
    radii: FloatArray,
    @FloatRange(from = 0.0) borderSize: Float = 0f,
    @ColorInt borderColor: Int = Color.TRANSPARENT,
): Bitmap {
    require(radii.size == 8) { "radii must have 8 values" }
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val resultBitmap = createBitmap(width, height, config ?: Bitmap.Config.ARGB_8888)
    val canvas = Canvas(resultBitmap)

    val rectF = RectF(0f, 0f, width.toFloat(), height.toFloat())
    if (borderSize > 0) {
        rectF.inset(borderSize / 2f, borderSize / 2f)
    }

    paint.shader = BitmapShader(this, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    val path = Path().apply {
        addRoundRect(rectF, radii, Path.Direction.CW)
    }
    canvas.drawPath(path, paint)

    if (borderSize > 0) {
        paint.shader = null
        paint.color = borderColor
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = borderSize
        paint.strokeJoin = Paint.Join.ROUND
        canvas.drawPath(path, paint)
    }

    return resultBitmap
}

/**
 * 将 Bitmap 保存到相册图片库
 * @param albumName 子文件夹名
 * @param displayName 文件名（不需加后缀，默认追加 .png）
 * @param format 压缩格式，默认 PNG
 * @param quality 压缩质量 0-100
 */
fun Bitmap.saveToAlbum(
    albumName: String? = null,
    displayName: String = "IMG_${System.currentTimeMillis()}",
    format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG,
    quality: Int = 100
): Uri? {
    val resolver = EaseKit.app.contentResolver

    val suffix = when (format) {
        Bitmap.CompressFormat.PNG -> ".png"
        Bitmap.CompressFormat.WEBP -> ".webp"
        else -> ".jpg"
    }

    val mimeType = when (format) {
        Bitmap.CompressFormat.PNG -> "image/png"
        Bitmap.CompressFormat.WEBP -> "image/webp"
        else -> "image/jpeg"
    }

    val finalFileName = if (displayName.endsWith(suffix)) displayName else "$displayName$suffix"

    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, finalFileName)
        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val baseDir = Environment.DIRECTORY_PICTURES
            val relativePath = if (albumName.isNullOrBlank()) baseDir else "$baseDir/$albumName"
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
    }

    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
              ?: return null

    return runCatching {
        resolver.openOutputStream(uri)?.use { outputStream ->
            this.compress(format, quality, outputStream)
        } ?: throw Exception("Failed to open output stream")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)
        }
        uri
    }.onFailure {
        resolver.delete(uri, null, null)
    }.getOrNull()
}

fun Bitmap.stackBlur(
    @FloatRange(from = 0.0, to = 1.0, fromInclusive = false) scale: Float,
    @IntRange(from = 1, to = 25) radius: Int,
): Bitmap {
    val scaleBitmap = scale(scale, scale)

    val w = scaleBitmap.width
    val h = scaleBitmap.height
    val pix = IntArray(w * h)
    scaleBitmap.getPixels(pix, 0, w, 0, 0, w, h)
    val wm = w - 1
    val hm = h - 1
    val wh = w * h
    val div = radius + radius + 1
    val r = IntArray(wh)
    val g = IntArray(wh)
    val b = IntArray(wh)
    var rSum: Int
    var gSum: Int
    var bSum: Int
    var x: Int
    var y: Int
    var i: Int
    var p: Int
    var yp: Int
    var yi = 0
    var yw = 0
    val vMin = IntArray(max(w, h))
    var divSum = div + 1 shr 1
    divSum *= divSum
    val dv = IntArray(256 * divSum)
    i = 0
    while (i < 256 * divSum) {
        dv[i] = i / divSum
        i++
    }
    val stack = Array(div) { IntArray(3) }
    var stackPointer: Int
    var stackStart: Int
    var sir: IntArray
    var rbs: Int
    val r1 = radius + 1
    var routSum: Int
    var goutSum: Int
    var boutSum: Int
    var rinSum: Int
    var ginSum: Int
    var binSum: Int
    y = 0
    while (y < h) {
        bSum = 0
        gSum = 0
        rSum = 0
        boutSum = 0
        goutSum = 0
        routSum = 0
        binSum = 0
        ginSum = 0
        rinSum = 0
        i = -radius
        while (i <= radius) {
            p = pix[yi + min(wm, max(i, 0))]
            sir = stack[i + radius]
            sir[0] = p and 0xff0000 shr 16
            sir[1] = p and 0x00ff00 shr 8
            sir[2] = p and 0x0000ff
            rbs = r1 - abs(i)
            rSum += sir[0] * rbs
            gSum += sir[1] * rbs
            bSum += sir[2] * rbs
            if (i > 0) {
                rinSum += sir[0]
                ginSum += sir[1]
                binSum += sir[2]
            } else {
                routSum += sir[0]
                goutSum += sir[1]
                boutSum += sir[2]
            }
            i++
        }
        stackPointer = radius
        x = 0
        while (x < w) {
            r[yi] = dv[rSum]
            g[yi] = dv[gSum]
            b[yi] = dv[bSum]
            rSum -= routSum
            gSum -= goutSum
            bSum -= boutSum
            stackStart = stackPointer - radius + div
            sir = stack[stackStart % div]
            routSum -= sir[0]
            goutSum -= sir[1]
            boutSum -= sir[2]
            if (y == 0) {
                vMin[x] = min(x + radius + 1, wm)
            }
            p = pix[yw + vMin[x]]
            sir[0] = p and 0xff0000 shr 16
            sir[1] = p and 0x00ff00 shr 8
            sir[2] = p and 0x0000ff
            rinSum += sir[0]
            ginSum += sir[1]
            binSum += sir[2]
            rSum += rinSum
            gSum += ginSum
            bSum += binSum
            stackPointer = (stackPointer + 1) % div
            sir = stack[stackPointer % div]
            routSum += sir[0]
            goutSum += sir[1]
            boutSum += sir[2]
            rinSum -= sir[0]
            ginSum -= sir[1]
            binSum -= sir[2]
            yi++
            x++
        }
        yw += w
        y++
    }
    x = 0
    while (x < w) {
        bSum = 0
        gSum = 0
        rSum = 0
        boutSum = 0
        goutSum = 0
        routSum = 0
        binSum = 0
        ginSum = 0
        rinSum = 0
        yp = -radius * w
        i = -radius
        while (i <= radius) {
            yi = max(0, yp) + x
            sir = stack[i + radius]
            sir[0] = r[yi]
            sir[1] = g[yi]
            sir[2] = b[yi]
            rbs = r1 - abs(i)
            rSum += r[yi] * rbs
            gSum += g[yi] * rbs
            bSum += b[yi] * rbs
            if (i > 0) {
                rinSum += sir[0]
                ginSum += sir[1]
                binSum += sir[2]
            } else {
                routSum += sir[0]
                goutSum += sir[1]
                boutSum += sir[2]
            }
            if (i < hm) {
                yp += w
            }
            i++
        }
        yi = x
        stackPointer = radius
        y = 0
        while (y < h) {
            pix[yi] = -0x1000000 and pix[yi] or (dv[rSum] shl 16) or (dv[gSum] shl 8) or dv[bSum]
            rSum -= routSum
            gSum -= goutSum
            bSum -= boutSum
            stackStart = stackPointer - radius + div
            sir = stack[stackStart % div]
            routSum -= sir[0]
            goutSum -= sir[1]
            boutSum -= sir[2]
            if (x == 0) {
                vMin[y] = min(y + r1, hm) * w
            }
            p = x + vMin[y]
            sir[0] = r[p]
            sir[1] = g[p]
            sir[2] = b[p]
            rinSum += sir[0]
            ginSum += sir[1]
            binSum += sir[2]
            rSum += rinSum
            gSum += ginSum
            bSum += binSum
            stackPointer = (stackPointer + 1) % div
            sir = stack[stackPointer]
            routSum += sir[0]
            goutSum += sir[1]
            boutSum += sir[2]
            rinSum -= sir[0]
            ginSum -= sir[1]
            binSum -= sir[2]
            yi += w
            y++
        }
        x++
    }
    scaleBitmap.setPixels(pix, 0, w, 0, 0, w, h)

    return scaleBitmap.scale(width, height)
}
