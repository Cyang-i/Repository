package com.cheny.kit.log

import com.cheny.kit.log.tree.Tree
import java.util.Collections
import java.util.Collections.unmodifiableList

/**
 * Log打印工具
 * @author: MasterChan
 * @date: 2022-05-28 23:20
 */
class Logger private constructor() {

    companion object Forest : Tree() {
        val treeCount: Int
            get() = treeArray.size

        private val trees = ArrayList<Tree>()

        @Volatile
        private var treeArray = arrayOf<Tree>()

        override fun v(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.v(message = message, args = args, tag = tag) }
        }

        override fun d(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.d(message = message, args = args, tag = tag) }
        }

        override fun i(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.i(message = message, args = args, tag = tag) }
        }

        override fun w(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.w(message = message, args = args, tag = tag) }
        }

        override fun e(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.e(message = message, args = args, tag = tag) }
        }

        override fun wtf(message: Any?, vararg args: Any?, tag: () -> String) {
            treeArray.forEach { it.wtf(message = message, args = args, tag = tag) }
        }

        override fun print(
            priority: Int,
            tag: String,
            message: String?,
            stackTrace: StackTraceElement?
        ) {
            treeArray.forEach {
                it.print(
                    priority = priority,
                    message = message,
                    tag = tag,
                    stackTrace = stackTrace
                )
            }
        }

        fun plant(tree: Tree) {
            require(tree !== this) { "Cannot plant Tree into itself." }
            synchronized(trees) {
                trees.add(tree)
                treeArray = trees.toTypedArray()
            }
        }

        fun plant(vararg trees: Tree) {
            for (tree in trees) {
                require(tree !== this) { "Cannot plant Tree into itself." }
            }
            synchronized(this.trees) {
                Collections.addAll(this.trees, *trees)
                treeArray = this.trees.toTypedArray()
            }
        }

        fun uproot(tree: Tree) {
            synchronized(trees) {
                require(trees.remove(tree)) { "Cannot uproot tree which is not planted: $tree" }
                treeArray = trees.toTypedArray()
            }
        }

        fun uprootAll() {
            synchronized(trees) {
                trees.clear()
                treeArray = emptyArray()
            }
        }

        fun forest(): List<Tree> {
            synchronized(trees) {
                return unmodifiableList(trees.toList())
            }
        }
    }
}