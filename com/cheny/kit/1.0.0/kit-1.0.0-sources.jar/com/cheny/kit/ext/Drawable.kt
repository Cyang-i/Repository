package com.cheny.kit.ext

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.view.View
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.graphics.drawable.toDrawable
import com.cheny.kit.EaseKit.app

fun Context.getDrawableStrict(@DrawableRes id: Int): Drawable? {
    return ContextCompat.getDrawable(this, id)
}

fun View.getDrawableStrict(@DrawableRes id: Int): Drawable? {
    return context.getDrawableStrict(id)
}

fun Drawable.toByteArray(
    format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG,
    quality: Int = 100
): ByteArray {
    return toBitmap().toByteArray(format, quality)
}

fun ByteArray.toDrawable(options: BitmapFactory.Options? = null): Drawable {
    return toBitmap(options).toDrawable(app.resources)
}