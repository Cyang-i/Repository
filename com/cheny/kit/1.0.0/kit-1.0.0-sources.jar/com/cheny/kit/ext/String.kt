package com.cheny.kit.ext

import com.cheny.kit.utils.RegexPool

/**
 * 提取文本中所有的纯数字
 * 例如: "价格100元，数量2个" -> ["100", "2"]
 */
fun String?.findAllNumbers(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractNumeric.findAll(this).map { it.value }.toList()
}

/**
 * 提取文本中所有的数值（支持负数和小数）
 * 例如: "温度-12.5度，高度100米" -> ["-12.5", "100"]
 */
fun String?.findAllDigits(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractDigits.findAll(this).map { it.value }.toList()
}

/**
 * 提取文本中所有的汉字
 */
fun String?.findAllChinese(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractChinese.findAll(this).map { it.value }.toList()
}

/**
 * 提取文本中所有的英文字母
 */
fun String?.findAllAlphabetic(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractAlphabetic.findAll(this).map { it.value }.toList()
}

/**
 * 提取文本中所有的非纯数字序列
 * 例如: "A123B" -> ["A", "B"]
 */
fun String?.findAllNonNumeric(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractNonNumeric.findAll(this).map { it.value }.toList()
}

/**
 * 提取文本中所有的非数值序列（排除数字、负号、小数点）
 * 例如: "温度-12.5度" -> ["温度", "度"]
 */
fun String?.findAllNonDigits(): List<String> {
    if (this == null) return emptyList()
    return RegexPool.extractNonDigits.findAll(this).map { it.value }.toList()
}