package com.cheny.kit.network

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import androidx.annotation.RequiresPermission
import androidx.core.content.getSystemService
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.cheny.kit.EaseKit
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn

object NetworkMonitor {

    @SuppressLint("MissingPermission")
    val networkInfo: StateFlow<NetworkInfo> = callbackFlow {
        val cm = EaseKit.app.getSystemService(ConnectivityManager::class.java)

        val callback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            object : ConnectivityManager.NetworkCallback(FLAG_INCLUDE_LOCATION_INFO) {
                @SuppressLint("MissingPermission")
                override fun onCapabilitiesChanged(
                    network: Network,
                    capabilities: NetworkCapabilities
                ) {
                    trySend(getNetworkInfo(capabilities))
                }

                override fun onLost(network: Network) {
                    trySend(NetworkInfo())
                }
            }
        } else {
            object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(
                    network: Network,
                    capabilities: NetworkCapabilities
                ) {
                    trySend(getNetworkInfo(capabilities))
                }

                override fun onLost(network: Network) {
                    trySend(NetworkInfo())
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.registerNetworkCallback(request, callback)
        } else {
            cm.registerDefaultNetworkCallback(callback)
        }

        awaitClose {
            cm.unregisterNetworkCallback(callback)
        }
    }
        .distinctUntilChanged()
        .conflate()
        .stateIn(
            scope = ProcessLifecycleOwner.get().lifecycleScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = getNetworkInfo()
        )

    @RequiresPermission(
        allOf = [Manifest.permission.ACCESS_NETWORK_STATE, Manifest.permission.READ_PHONE_STATE]
    )
    fun getNetworkInfo(): NetworkInfo {
        val cm = EaseKit.app.getSystemService(ConnectivityManager::class.java)

        val network = cm.activeNetwork ?: return NetworkInfo()
        val capabilities = cm.getNetworkCapabilities(network) ?: return NetworkInfo()
        return getNetworkInfo(capabilities)
    }

    @RequiresPermission(Manifest.permission.READ_PHONE_STATE)
    fun getNetworkInfo(capabilities: NetworkCapabilities): NetworkInfo {
        val isConnected = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val isAvailable = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val isVpn = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                NetworkInfo(
                    isConnected = isConnected,
                    isValidated = isAvailable,
                    isVpn = isVpn,
                    type = NetworkType.Wifi(getSsid(EaseKit.app, capabilities))
                )
            }
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                NetworkInfo(
                    isConnected = isConnected,
                    isValidated = isAvailable,
                    isVpn = isVpn,
                    type = getMobileNetworkType(EaseKit.app)
                )
            }
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                NetworkInfo(
                    isConnected = isConnected,
                    isValidated = isAvailable,
                    isVpn = isVpn,
                    type = NetworkType.Ethernet
                )
            }
            else -> {
                NetworkInfo(
                    isConnected = isConnected,
                    isValidated = isAvailable,
                    isVpn = isVpn,
                    type = NetworkType.None
                )
            }
        }
    }

    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    fun isValidated(): Boolean {
        val cm = EaseKit.app.getSystemService<ConnectivityManager>() ?: return false
        val capabilities = cm.getNetworkCapabilities(cm.activeNetwork)
        return capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }

    private fun getSsid(context: Context, capabilities: NetworkCapabilities): String? {
        try {
            var ssid: String? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val transportInfo = capabilities.transportInfo
                if (transportInfo is WifiInfo) {
                    ssid = transportInfo.ssid
                }
            }
            if (ssid == WifiManager.UNKNOWN_SSID || ssid.isNullOrEmpty()) {
                ssid = context.getSystemService(WifiManager::class.java)?.connectionInfo?.ssid
            }
            return ssid?.replace("\"", "")
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * 获取移动网络具体代际 (4G/5G 等)
     */
    @RequiresPermission(Manifest.permission.READ_PHONE_STATE)
    private fun getMobileNetworkType(context: Context): NetworkType.Cellular {
        val tm = context.getSystemService(TelephonyManager::class.java)
        return when (tm.dataNetworkType) {
            TelephonyManager.NETWORK_TYPE_GPRS,
            TelephonyManager.NETWORK_TYPE_EDGE -> NetworkType.Cellular.C2G

            TelephonyManager.NETWORK_TYPE_UMTS,
            TelephonyManager.NETWORK_TYPE_HSPA,
            TelephonyManager.NETWORK_TYPE_HSPAP,
            TelephonyManager.NETWORK_TYPE_HSDPA,
            TelephonyManager.NETWORK_TYPE_HSUPA -> NetworkType.Cellular.C3G

            TelephonyManager.NETWORK_TYPE_LTE -> NetworkType.Cellular.C4G
            TelephonyManager.NETWORK_TYPE_NR -> NetworkType.Cellular.C5G
            TelephonyManager.NETWORK_TYPE_UNKNOWN -> NetworkType.Cellular.Unknown
            else -> NetworkType.Cellular.Unknown
        }
    }
}