package com.cheny.ui.shadow

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.InsetDrawable
import android.util.AttributeSet
import android.view.View
import androidx.core.content.withStyledAttributes
import com.cheny.ui.R
import com.cheny.ui.StateType
import com.cheny.ui.StateType.CHECKED.androidState
import com.cheny.ui.annotation.RenderMode
import com.cheny.ui.ext.getCornerSize
import com.google.android.material.shape.CornerTreatment
import com.google.android.material.shape.EdgeTreatment
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.shape.ShapeAppearanceModel
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.sqrt

/**
 * ShadowViewDelegate
 * @author: MasterChan
 * @date: 2025-05-06 16:43
 */
@SuppressLint("RestrictedApi")
class ShadowViewDelegate(
    context: Context? = null,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : IShadowView {
    private lateinit var target: View

    override var stateType: StateType = StateType.NONE
    override var contentColor: Int = -1
    override var contentColorState: Int = -1
    override var contentColorDisable: Int = -1
    override var strokeColor: Int = -1
    override var strokeColorState: Int = -1
    override var strokeColorDisable: Int = -1
    override var strokeWidth: Float = 0f
    override var strokeWidthState: Float = 0f
    override var strokeWidthDisable: Float = 0f
    override var shadowEnable: Boolean = true
    override var shadowColour: Int = Color.BLACK
    override var shadowElevation: Float = 0f
    override var shadowOffsetY: Float = 0f
    override var shadowOffsetX: Float = 0f
    override var shadowFollowContent: Boolean = true
    override var autoInset: Boolean = false
    override var renderMode: Int = RenderMode.BACKGROUND

    override val topLeftCornerSize: Float
        get() = shapedDrawable.shapeAppearanceModel.topLeftCornerSize.getCornerSize(RectF())
    override val topRightCornerSize: Float
        get() = shapedDrawable.shapeAppearanceModel.topRightCornerSize.getCornerSize(RectF())
    override val bottomLeftCornerSize: Float
        get() = shapedDrawable.shapeAppearanceModel.bottomLeftCornerSize.getCornerSize(RectF())
    override val bottomRightCornerSize: Float
        get() = shapedDrawable.shapeAppearanceModel.bottomRightCornerSize.getCornerSize(RectF())
    override val topLeftCorner: CornerTreatment
        get() = shapedDrawable.shapeAppearanceModel.topLeftCorner
    override val topRightCorner: CornerTreatment
        get() = shapedDrawable.shapeAppearanceModel.topRightCorner
    override val bottomLeftCorner: CornerTreatment
        get() = shapedDrawable.shapeAppearanceModel.bottomLeftCorner
    override val bottomRightCorner: CornerTreatment
        get() = shapedDrawable.shapeAppearanceModel.bottomRightCorner
    override val leftEdge: EdgeTreatment
        get() = shapedDrawable.shapeAppearanceModel.leftEdge
    override val topEdge: EdgeTreatment
        get() = shapedDrawable.shapeAppearanceModel.topEdge
    override val rightEdge: EdgeTreatment
        get() = shapedDrawable.shapeAppearanceModel.rightEdge
    override val bottomEdge: EdgeTreatment
        get() = shapedDrawable.shapeAppearanceModel.bottomEdge

    override var contentColorDirty = true
    override var strokeColorDirty = true
    override val shapedBuilder = ShapeAppearanceModel().toBuilder()

    private val shapedDrawable = MaterialShapeDrawable()
    private var isSelected: Boolean? = null
    private var isDisable: Boolean? = null
    private var contentColorList: ColorStateList? = null
    private var strokeColorList: ColorStateList? = null

    init {
        if (context != null && attrs != null) {
            initAttrs(context, attrs, defStyleAttr, defStyleRes)
        }
    }

    private fun initAttrs(
        context: Context,
        attrs: AttributeSet,
        defStyleAttr: Int,
        defStyleRes: Int
    ) {
        context.withStyledAttributes(
            attrs, R.styleable.ShadowView, defStyleAttr, defStyleRes
        ) {
            stateType = StateType.from(getInt(R.styleable.ShadowView_cheny_stateType, -1))
            shadowEnable = getBoolean(R.styleable.ShadowView_cheny_shadowEnable, true)
            shadowElevation = getDimension(R.styleable.ShadowView_cheny_shadowElevation, 0f)
            shadowColour = getColor(R.styleable.ShadowView_cheny_shadowColor, Color.BLACK)
            shadowOffsetX = getDimension(R.styleable.ShadowView_cheny_shadowOffsetX, 0f)
            shadowOffsetY = getDimension(R.styleable.ShadowView_cheny_shadowOffsetY, 0f)
            shadowFollowContent = getBoolean(R.styleable.ShadowView_cheny_shadowFollowContent, true)
            autoInset = getBoolean(R.styleable.ShadowView_cheny_autoInset, false)
            renderMode = getInteger(
                R.styleable.ShadowView_cheny_renderMode, RenderMode.BACKGROUND
            )
            if (hasValue(R.styleable.ShadowView_cheny_selected)) {
                isSelected = getBoolean(R.styleable.ShadowView_cheny_selected, false)
            }
            if (hasValue(R.styleable.ShadowView_cheny_disable)) {
                isDisable = getBoolean(R.styleable.ShadowView_cheny_disable, false)
            }
            val cornerSize = getCornerSize(R.styleable.ShadowView_cheny_cornerSize) { 0f }
            val cornerFamily = getInteger(R.styleable.ShadowView_cheny_cornerFamily, 0)
            setTopLeftCorner(
                getInteger(R.styleable.ShadowView_cheny_cornerFamilyTopLeft, cornerFamily),
                getCornerSize(R.styleable.ShadowView_cheny_cornerSizeTopLeft, cornerSize)
            )
            setTopRightCorner(
                getInteger(R.styleable.ShadowView_cheny_cornerFamilyTopRight, cornerFamily),
                getCornerSize(R.styleable.ShadowView_cheny_cornerSizeTopRight, cornerSize)
            )
            setBottomLeftCorner(
                getInteger(R.styleable.ShadowView_cheny_cornerFamilyBottomLeft, cornerFamily),
                getCornerSize(R.styleable.ShadowView_cheny_cornerSizeBottomLeft, cornerSize)
            )
            setBottomRightCorner(
                getInteger(R.styleable.ShadowView_cheny_cornerFamilyBottomRight, cornerFamily),
                getCornerSize(R.styleable.ShadowView_cheny_cornerSizeBottomRight, cornerSize)
            )
            strokeWidth = getDimension(R.styleable.ShadowView_cheny_strokeWidth, 0f)
            strokeColor = getColor(R.styleable.ShadowView_cheny_strokeColor, Color.BLACK)
            strokeColorState = getColor(R.styleable.ShadowView_cheny_strokeColor_state, strokeColor)
            strokeColorDisable = getColor(
                R.styleable.ShadowView_cheny_strokeColor_disable, strokeColor
            )
            contentColor = getColor(R.styleable.ShadowView_cheny_contentColor, Color.WHITE)
            contentColorState = getColor(
                R.styleable.ShadowView_cheny_contentColor_state, contentColor
            )
            contentColorDisable = getColor(
                R.styleable.ShadowView_cheny_contentColor_disable, contentColor
            )
        }
    }

    override fun setup() = into(target)

    override fun into(target: View) {
        this.target = target
        if (contentColorDirty) {
            contentColorDirty = false
            contentColorList = createColorStateList(
                listOf(contentColor, contentColorState, contentColorDisable)
            )
        }
        if (strokeColorDirty) {
            strokeColorDirty = false
            strokeColorList = createColorStateList(
                listOf(strokeColor, strokeColorState, strokeColorDisable)
            )
        }

        shapedDrawable.initializeElevationOverlay(target.context)
        shapedDrawable.setShapeAppearanceModel(shapedBuilder.build())
        shapedDrawable.shadowCompatibilityMode = if (shadowEnable) {
            MaterialShapeDrawable.SHADOW_COMPAT_MODE_ALWAYS
        } else {
            MaterialShapeDrawable.SHADOW_COMPAT_MODE_NEVER
        }
        if (shapedDrawable.fillColor != contentColorList) {
            shapedDrawable.fillColor = contentColorList
        }
        if (shapedDrawable.strokeWidth != strokeWidth) {
            shapedDrawable.strokeWidth = strokeWidth
        }
        if (shapedDrawable.strokeColor != strokeColorList) {
            shapedDrawable.strokeColor = strokeColorList
        }
        if (shapedDrawable.elevation != shadowElevation) {
            shapedDrawable.elevation = shadowElevation
        }
        if (shadowFollowContent) {
            shapedDrawable.setUseTintColorForShadow(true)
            shapedDrawable.tintList = contentColorList
        } else {
            shapedDrawable.setShadowColor(shadowColour)
            shapedDrawable.setUseTintColorForShadow(false)
            shapedDrawable.tintList = null
        }
        setShadowOffset(shadowOffsetX, shadowOffsetY)
        val drawable: Drawable
        if (autoInset) {
            val left = max(shadowElevation - shadowOffsetX, 0f).toInt()
            val top = max(shadowElevation - shadowOffsetY, 0f).toInt()
            val right = max(shadowElevation + shadowOffsetX, 0f).toInt()
            val bottom = max(shadowElevation + shadowOffsetY, 0f).toInt()
            drawable = InsetDrawable(shapedDrawable, left, top, right, bottom)
        } else {
            drawable = shapedDrawable
        }
        if (renderMode == RenderMode.BACKGROUND) {
            this.target.background = drawable
        } else {
            this.target.foreground = drawable
        }
        if (isSelected != null) {
            this.target.isSelected = isSelected!!
            isSelected = null
        }
        if (isDisable != null) {
            this.target.isEnabled = !isDisable!!
            isDisable = null
        }
    }

    private fun createColorStateList(colors: List<Int>): ColorStateList {
        val normalColor = colors[0]
        val stateColor = colors[1]
        val disableColor = colors[2]
        return if (stateType != StateType.NONE) {
            val stateTypeState = stateType.androidState
            ColorStateList(
                arrayOf(
                    intArrayOf(android.R.attr.state_enabled, -stateTypeState),
                    intArrayOf(android.R.attr.state_enabled, stateTypeState),
                    intArrayOf(-android.R.attr.state_enabled)
                ),
                intArrayOf(normalColor, stateColor, disableColor)
            )
        } else {
            ColorStateList(
                arrayOf(
                    intArrayOf(android.R.attr.state_enabled),
                    intArrayOf(-android.R.attr.state_enabled)
                ),
                intArrayOf(normalColor, disableColor)
            )
        }
    }

    private fun setShadowOffset(x: Float, y: Float) {
        // 计算角度和距离（极坐标转换）
        val angleRad = atan2(x.toDouble(), y.toDouble())
        val angle = Math.toDegrees(angleRad).toInt()
        val distance = sqrt((x * x + y * y).toDouble())
        // 设置阴影方向和距离
        shapedDrawable.shadowCompatRotation = angle
        shapedDrawable.shadowVerticalOffset = distance.toInt()
    }
}