package com.cheny.ui.shape

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatButton
import com.cheny.ui.StateType
import com.cheny.ui.text.IStateText
import com.cheny.ui.text.StateTextDelegate

/**
 * ShapedButton
 * @author: MasterChan
 * @date: 2023-03-11 21:36
 */
open class ShapedButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatButton(context, attrs, defStyleAttr),
    IShapedView by ShapedViewDelegate(context, attrs),
    IStateText by StateTextDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
        setStateTextTarget(this).setStateTextStateType(stateType)
    }

    override fun setStateType(stateType: StateType): IShapedView {
        setStateTextStateType(stateType)
        return super.setStateType(stateType)
    }
}