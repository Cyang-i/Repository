package com.cheny.ui.dialog

import com.cheny.ui.dialog.animator.BgAnimator
import com.cheny.ui.dialog.animator.ContentAnimator

/**
 * AnimatorFactory
 * @author: MasterChan
 * @date: 2025-12-22 11:11
 */
open class AnimatorFactory {
    open fun createContentAnimator(): ContentAnimator {
        return ContentAnimator()
    }

    open fun createBgAnimator(): BgAnimator {
        return BgAnimator()
    }
}