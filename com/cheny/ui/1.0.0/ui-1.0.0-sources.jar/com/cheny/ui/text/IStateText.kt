package com.cheny.ui.text

import android.widget.TextView
import androidx.annotation.ColorInt
import com.cheny.ui.StateType

/**
 * IStateText
 * @author: MasterChan
 * @date: 2025-05-07 14:13
 */
interface IStateText {

    var textColorState: Int
    var textColorDisable: Int
    var stateTextStateType: StateType
    var stateTextTarget: TextView?

    fun setTextColorState(@ColorInt textColorState: Int): IStateText

    fun setTextColorDisable(@ColorInt textColorDisable: Int): IStateText

    fun setTextColor(
        @ColorInt textColor: Int,
        @ColorInt textColorState: Int,
        @ColorInt textColorDisable: Int
    ): IStateText

    fun setStateTextStateType(stateType: StateType) = apply {
        this.stateTextStateType = stateType
    }

    fun setStateTextTarget(target: TextView) = apply {
        this.stateTextTarget = target
    }
}