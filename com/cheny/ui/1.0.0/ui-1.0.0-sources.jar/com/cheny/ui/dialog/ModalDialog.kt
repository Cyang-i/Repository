package com.cheny.ui.dialog

import android.R.attr.navigationBarColor
import android.R.attr.statusBarColor
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.annotation.CallSuper
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.core.graphics.drawable.toDrawable
import androidx.core.graphics.toColorInt
import androidx.core.graphics.toRectF
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.lifecycleScope
import androidx.viewbinding.ViewBinding
import com.cheny.ui.R
import com.cheny.ui.dialog.animator.AbsDialogAnimator
import com.cheny.ui.dialog.animator.AnimatorItem
import com.cheny.ui.dialog.animator.BgAnimator
import com.cheny.ui.dialog.animator.ContentAnimator
import com.cheny.ui.ext.frameLayoutParams
import com.cheny.ui.ext.getGlobalVisibleRect
import com.cheny.kit.ext.KeyboardState
import com.cheny.kit.ext.activity
import com.cheny.kit.ext.castOrNull
import com.cheny.kit.ext.hideKeyboard
import com.cheny.kit.ext.keyboardState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * ModalDialog
 * @author: MasterChan
 * @date: 2023-12-19 14:30
 */
@SuppressLint("ClickableViewAccessibility")
@Suppress("DEPRECATION")
abstract class ModalDialog(val context: Context) : IDialog, LifecycleOwner {

    companion object {
        var animatorFactory = AnimatorFactory()

        private typealias DialogCache = ConcurrentHashMap<String, ModalDialog>

        private val dialogCache = DialogCache()

        private fun DialogCache.onShow(dialog: ModalDialog) {
            put(dialog.tag, dialog)
        }

        private fun DialogCache.onDismiss(dialog: ModalDialog) {
            remove(dialog.tag)
        }

        @JvmName("findDialog")
        fun find(tag: String): ModalDialog? {
            return dialogCache[tag]
        }

        fun <T : ModalDialog> find(tag: String): T? {
            return dialogCache[tag].castOrNull()
        }

        fun dismiss(tag: String) {
            dialogCache.remove(tag)
        }
    }

    final override val lifecycle by lazy { LifecycleRegistry(this) }
    override var contentWidth: Int? = null
    override var contentHeight: Int? = null
    override var isDismissOnBackPressed: Boolean = true
    override var isDismissOnTouchOutside: Boolean = true
    override var isHideKeyboardOnTouchOutside: Boolean = true
    override val isUpKeyboard: Boolean = true
    override var isTouchThrough: Boolean = false
    override var offsetX: Int = 0
    override var offsetY: Int = 0
    override var contentAnimator: AbsDialogAnimator? = null
    override var bgAnimator: BgAnimator? = null
    override var animatorDuration: Long = 300
    override var enableAnimator: Boolean = true
    override var bgColor: Int = "#7F000000".toColorInt()
    override var isBgBlur: Boolean = false
    override var contentGravity: Int = -1
    override var isHideNavigationBar: Boolean = false
    override var isNavigationBarLight: Boolean? = null
    override var isHideStatusBar: Boolean = false
    override var isStatusBarLight: Boolean? = null
    override var tag: String = ""

    protected val container = FrameLayout(context)
    protected var dialog: Dialog? = null
    private var isCreated = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var lastX = 0f
    private var lastY = 0f
    private var contentAnimItems: MutableList<AnimatorItem>? = null
    private var onShowListener: OnShowListener? = null
    private var onDismissListener: OnDismissListener? = null
    private var onBackPressedListener: OnBackPressedListener? = null
    private var keyboardState: KeyboardState? = null

    var contentView: View? = null
        private set
    var state: State = State.Idle
        private set

    init {
        container.setOnTouchListener(::onTouchEvent)
        context.activity?.castOrNull<FragmentActivity>()?.lifecycle?.addObserver(object :
            DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                dismissInternal()
            }
        })
    }

    protected abstract fun onCreate()

    protected open fun setContentView(@LayoutRes layout: Int) {
        setContentView(LayoutInflater.from(context).inflate(layout, container, false))
    }

    protected open fun setContentView(contentView: View) {
        this.contentView = contentView
        container.addView(contentView)
        if (contentGravity == -1) {
            contentGravity = contentView.frameLayoutParams.gravity
        }
    }

    protected open fun onTouchEvent(view: View, event: MotionEvent): Boolean {
        val rect = contentView!!.getGlobalVisibleRect().toRectF()
        if (!rect.contains(event.x, event.y)) {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    if (isTouchThrough) {
                        context.activity?.dispatchTouchEvent(event)
                    }
                }

                MotionEvent.ACTION_MOVE -> {
                    handleTouchOutside()
                    if (isTouchThrough) {
                        context.activity?.dispatchTouchEvent(event)
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    val distance = sqrt(dx.toDouble().pow(2) + dy.toDouble().pow(2))
                    if (distance < touchSlop) {
                        handleTouchOutside()
                    }
                    if (isTouchThrough) {
                        context.activity?.dispatchTouchEvent(event)
                    }
                    lastX = 0f
                    lastY = 0f
                }
            }
        }
        return true
    }

    /**
     * 处理[contentView]之外的Touch事件
     */
    protected open fun handleTouchOutside() {
        if (isDismissOnTouchOutside) {
            if (isHideKeyboardOnTouchOutside && keyboardState?.isVisible == true) {
                dialog!!.currentFocus?.hideKeyboard()
            } else {
                dismiss()
            }
        } else {
            if (isHideKeyboardOnTouchOutside && keyboardState?.isVisible == true) {
                dialog!!.currentFocus?.hideKeyboard()
            }
        }
    }

    override fun show(tag: String?) = apply {
        val activity = context.activity
        if (activity == null || activity.isFinishing || activity.isDestroyed) return@apply
        if (dialog?.isShowing == true) return@apply
        if (!(state == State.Idle || state == State.Dismissal)) return@apply

        if (dialog == null) {
            //创建Dialog并初始化一些设置和分发事件
            dialog = Dialog(context, R.style.BaseDialog)
            dialog!!.setContentView(container)
            dialog!!.window!!.setBackgroundDrawable(0.toDrawable())
            dialog!!.setOnKeyListener { _, keyCode, keyEvent -> onKeyEvent(keyCode, keyEvent) }
            dialog!!.setOnShowListener(::onShowInternal)
        }

        this.tag = tag ?: hashCode().toString()
        if (!isCreated) {
            isCreated = true
            dialog?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            onCreate()
            lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            container.keyboardState.onEach {
                onKeyboardChanged(it)
            }.launchIn(lifecycleScope)
        }
        setSystemBars(dialog!!.window!!)
        initContentView()
        dialog!!.show()
    }

    protected open fun setSystemBars(window: Window) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (isHideStatusBar) {
            controller.hide(WindowInsetsCompat.Type.statusBars())
            return
        }
        //设置状态栏颜色模式
        isStatusBarLight?.let {
            controller.isAppearanceLightStatusBars = it
        }
        //设置状态栏颜色
        window.statusBarColor = statusBarColor

        if (isHideNavigationBar) {
            controller.hide(WindowInsetsCompat.Type.navigationBars())
            return
        }
        //设置导航栏颜色模式
        isNavigationBarLight?.let {
            controller.isAppearanceLightNavigationBars = it
        }
        //设置导航栏颜色
        window.navigationBarColor = navigationBarColor
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
    }

    protected open fun initContentView() {
        require(contentView != null) {
            "contentView is null,call setContentView() in onCreate() first"
        }
        val params = contentView!!.layoutParams as FrameLayout.LayoutParams
        contentWidth?.let { params.width = it }
        contentHeight?.let { params.height = it }
        contentView!!.layoutParams = params
        params.gravity = contentGravity
        contentView!!.translationX = offsetX.toFloat()
        contentView!!.translationY = offsetY.toFloat()
        //先隐藏ContentView，防止跳闪
        contentView!!.alpha = 0f
    }

    protected open fun onKeyboardChanged(state: KeyboardState) {
        keyboardState ?: return
        if (isUpKeyboard) {
            if (state.isVisible) {
                if (container.height - state.height < contentView!!.bottom + offsetY) {
                    contentView!!.animate()
                        .setDuration(250)
                        .translationY(
                            -(contentView!!.bottom.toFloat() - (container.height - state.height))
                        )
                        .start()
                }
            } else {
                contentView!!.animate().setDuration(250).translationY(offsetY.toFloat()).start()
            }
        }
        keyboardState = state
    }

    /**
     * 按键事件监听，由[dialog]分发
     * @param keyCode Int
     * @param keyEvent KeyEvent
     * @return Boolean
     */
    protected open fun onKeyEvent(keyCode: Int, keyEvent: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && keyEvent.action == KeyEvent.ACTION_UP) {
            return when {
                onBackPressedListener?.onBackPressed(this) == true || onBackPressed() -> true

                keyboardState?.isVisible == false -> {
                    if (isDismissOnBackPressed) dismiss()
                    true
                }

                else -> false
            }
        }
        return false
    }

    /**
     * 返回键事件监听，其优先级低于[onBackPressedListener]，[onBackPressedListener]返回false，
     * [onBackPressed]会接收到事件，反之不会接收到事件
     *
     * @return Boolean
     */
    protected open fun onBackPressed(): Boolean {
        return false
    }

    /**
     * 真正的dialog显示时调用
     * @param dialog DialogInterface
     */
    protected open fun onShowInternal(dialog: DialogInterface) {
        onStart()
        lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_START)
        dialogCache.onShow(this)
    }

    @CallSuper
    protected open fun onStart() {
        state = State.Showing
        onInitAnimator()
        if (enableAnimator) {
            //如果没有Alpha动画，手动将Alpha置为1
            val animatorItems = contentAnimator.castOrNull<ContentAnimator>()?.animatorItems
            if (animatorItems?.contains(AnimatorItem.Alpha) != true) {
                contentView?.alpha = 1f
            }
            bgAnimator!!.show { onShowAnimator() }
            contentAnimator?.show()
        } else {
            contentView?.alpha = 1f
            container.setBackgroundColor(bgColor)
            onShowAnimator()
        }
    }

    /**
     * 动画初始化，动画包含背景动画和ContentView的动画；如果未自定义ContentView动画，则使用默认动画，
     * 默认动画会根据[contentGravity]的方向设置不同的动画
     */
    protected open fun onInitAnimator() {
        //初始化背景动画
        if (bgAnimator == null) {
            bgAnimator = animatorFactory.createBgAnimator()
        }
        bgAnimator!!.target = container
        bgAnimator!!.duration = animatorDuration
        bgAnimator!!.bgColor = bgColor
        bgAnimator!!.init()

        //初始化内容动画
        if (contentAnimator == null) {
            contentAnimator = animatorFactory.createContentAnimator()
        }
        contentAnimator!!.target = contentView
        contentAnimator!!.duration = animatorDuration
        contentAnimator!!.init()

        //设置默认内容动画
        if (contentAnimator is ContentAnimator) {
            val animator = contentAnimator as ContentAnimator
            if (contentAnimItems == null) {
                animator.clearAnimatorItems()
                when {
                    contentGravity and Gravity.VERTICAL_GRAVITY_MASK == Gravity.TOP -> {
                        animator.addAnimatorItem(AnimatorItem.Translate.Top)
                    }

                    contentGravity == Gravity.CENTER -> {
                        animator.addAnimatorItem(AnimatorItem.Alpha)
                        animator.addAnimatorItem(AnimatorItem.Scale.Center)
                    }

                    contentGravity and Gravity.VERTICAL_GRAVITY_MASK == Gravity.BOTTOM -> {
                        animator.addAnimatorItem(AnimatorItem.Translate.Bottom)
                    }
                }
            } else {
                animator.setAnimatorItems(contentAnimItems!!)
            }
        }
    }

    protected open fun onShowAnimator() {
        state = State.Shown
        onShowListener?.onShow(this)
        onResume()
        lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    protected open fun onResume() {}

    override fun dismiss(delay: Long) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { delay(delay) }
            if (state == State.Dismissing || state == State.Dismissal) return@launch

            state = State.Dismissing
            onPause()
            lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            if (enableAnimator) {
                if (bgAnimator != null) {
                    bgAnimator!!.dismiss { dismissInternal() }
                } else {
                    dismissInternal()
                }
                contentAnimator?.dismiss()
            } else {
                contentView?.alpha = 1f
                dismissInternal()
            }
        }
    }

    private fun dismissInternal() {
        state = State.Dismissal
        if (context.activity?.isDestroyed == true) {
            return
        } else {
            dialog?.dismiss()
        }
        onDismissListener?.onDismiss(this)
        onStop()
        lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        dialogCache.onDismiss(this)
    }

    protected open fun onPause() {}

    @CallSuper
    protected open fun onStop() {
        tryRemoveFragments()
    }

    override fun update(x: Int, y: Int) {
        contentView ?: return
        offsetX = x
        offsetY = y
        contentView!!.translationX = x.toFloat()
        contentView!!.translationY = y.toFloat()
    }

    protected open fun tryRemoveFragments() {
        if (context is FragmentActivity) {
            val manager = context.supportFragmentManager
            val fragments = manager.fragments
            val fragmentNames = getFragmentNames()
            if (fragments.isNotEmpty() && !fragmentNames.isNullOrEmpty()) {
                fragments.forEachIndexed { index, fragment ->
                    if (fragmentNames.contains(fragment.javaClass.simpleName)) {
                        manager.beginTransaction()
                            .remove(fragments[index])
                            .commitAllowingStateLoss()
                    }
                }
            }
        }
    }

    protected open fun getFragmentNames(): List<String>? {
        return null
    }

    protected fun <T : View> findViewById(@IdRes id: Int): T {
        return container.findViewById(id)
    }

    protected inline fun <reified T : ViewBinding> viewBind(): T {
        val inflateMethod = T::class.java.getMethod(
            "inflate", LayoutInflater::class.java, ViewGroup::class.java, Boolean::class.java
        )
        return inflateMethod.invoke(null, LayoutInflater.from(context), container, false) as T
    }

    fun setContentAnimator(item: AnimatorItem) = apply {
        if (contentAnimItems == null) {
            contentAnimItems = mutableListOf(item)
        } else {
            contentAnimItems?.clear()
            contentAnimItems?.add(item)
        }
    }

    fun setContentAnimator(items: List<AnimatorItem>) = apply {
        if (contentAnimItems == null) {
            contentAnimItems = ArrayList(items)
        } else {
            contentAnimItems?.clear()
            contentAnimItems?.addAll(items)
        }
    }

    fun setOnShowListener(onShowListener: OnShowListener) = apply {
        this.onShowListener = onShowListener
    }

    fun setOnDismissListener(onDismissListener: OnDismissListener) = apply {
        this.onDismissListener = onDismissListener
    }

    fun setOnBackPressedListener(onBackPressedListener: OnBackPressedListener) = apply {
        this.onBackPressedListener = onBackPressedListener
    }

    sealed class State(private val value: Int) {
        data object Idle : State(0)

        /**
         * 正在显示，此时[dialog]已经显示，[Dialog.isShowing]位于true状态，可能正处于显示动画执行阶段
         */
        data object Showing : State(1)

        /**
         * 已经完成显示，此时动画已经执行完毕
         */
        data object Shown : State(2)

        /**
         * 正在隐藏，此时[dialog]还未隐藏，[Dialog.isShowing]位于true状态；正处于隐藏动画执行阶段
         */
        data object Dismissing : State(3)

        /**
         * 已经隐藏，此时已经调用了[Dialog.dismiss]
         */
        data object Dismissal : State(4)

        operator fun minus(state2: State): Int {
            return value - state2.value
        }
    }

    fun interface OnShowListener {
        fun onShow(dialog: ModalDialog)
    }

    fun interface OnDismissListener {
        fun onDismiss(dialog: ModalDialog)
    }

    fun interface OnBackPressedListener {
        fun onBackPressed(dialog: ModalDialog): Boolean
    }
}