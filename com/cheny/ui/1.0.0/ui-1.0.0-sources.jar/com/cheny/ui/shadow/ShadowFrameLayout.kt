package com.cheny.ui.shadow

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/**
 * ShapedFrameLayout
 * @author: MasterChan
 * @date: 2023-03-11 21:36
 */
open class ShadowFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr), IShadowView by ShadowViewDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
    }
}