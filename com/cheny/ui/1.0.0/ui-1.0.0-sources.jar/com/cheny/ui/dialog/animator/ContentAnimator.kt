package com.cheny.ui.dialog.animator

import android.animation.AnimatorSet
import android.animation.IntEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View
import androidx.core.animation.doOnEnd
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import kotlin.math.max

/**
 * contentView默认动画，由不同的[AnimatorItem]组合而成
 * @author: MasterChan
 * @date: 2023-12-29 15:11
 */
open class ContentAnimator(protected open val scaleFactor: Float = 0.85f) : AbsDialogAnimator() {

    val animatorItems = mutableListOf<AnimatorItem>()

    protected open val intEvaluator by lazy { IntEvaluator() }
    protected open var initTranslateX = 0f
    protected open var initTranslateY = 0f
    protected open var targetTranslateX = 0f
    protected open var targetTranslateY = 0f
    protected open var initPivotX = 0f
    protected open var initPivotY = 0f
    protected open var targetPivotX = 0f
    protected open var targetPivotY = 0f
    protected open var startScrollX = 0
    protected open var startScrollY = 0

    override fun init() {
        initTranslateX = target!!.translationX
        initTranslateY = target!!.translationY
        targetTranslateX = initTranslateX
        targetTranslateY = initTranslateY

        initPivotX = target!!.pivotX
        initPivotY = target!!.pivotY
        targetPivotX = initPivotX
        targetPivotY = initPivotY
    }

    override fun show(onEnd: (() -> Unit)?) {
        val set = AnimatorSet()
        setTargetPivot()
        animatorItems.forEach { setShowAnimator(it, set) }
        set.interpolator = FastOutSlowInInterpolator()
        set.duration = duration
        set.doOnEnd { onEnd?.invoke() }
        set.start()
    }

    override fun dismiss(onEnd: (() -> Unit)?) {
        val set = AnimatorSet()
        setTargetPivot()
        animatorItems.forEach { setDismissAnimator(it, set) }
        set.interpolator = FastOutSlowInInterpolator()
        set.duration = duration
        set.doOnEnd {
            target!!.scaleX = 1f
            target!!.scaleY = 1f
            target!!.pivotX = initPivotX
            target!!.pivotY = initPivotY
            target!!.translationX = initTranslateX
            target!!.translationY = initTranslateY
            target!!.scrollX = 0
            target!!.scrollY = 0
            onEnd?.invoke()
        }
        set.start()
    }

    protected open fun setTargetPivot() {
        animatorItems.forEach {
            when (it) {
                AnimatorItem.Alpha -> target!!.alpha = 0f
                AnimatorItem.Translate.Left -> targetTranslateX = -target!!.width.toFloat()
                AnimatorItem.Translate.Top -> targetTranslateY = -target!!.measuredHeight.toFloat()
                AnimatorItem.Translate.Right -> targetTranslateX = target!!.measuredWidth.toFloat()
                AnimatorItem.Translate.Bottom -> targetTranslateY = target!!.measuredHeight.toFloat()

                AnimatorItem.Scale.Center -> {
                    targetPivotX = target!!.measuredWidth / 2f
                    targetPivotY = target!!.measuredHeight / 2f
                }

                AnimatorItem.Scale.TopLeft -> {
                    targetPivotX = 0f
                    targetPivotY = 0f
                }

                AnimatorItem.Scale.TopCenter -> {
                    targetPivotX = target!!.measuredWidth / 2f
                    targetPivotY = 0f
                }

                AnimatorItem.Scale.TopRight -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = 0f
                }

                AnimatorItem.Scale.BottomLeft -> {
                    targetPivotX = 0f
                    targetPivotY = target!!.measuredHeight.toFloat()
                }

                AnimatorItem.Scale.BottomCenter -> {
                    targetPivotX = target!!.measuredWidth / 2f
                    targetPivotY = target!!.measuredHeight.toFloat()
                }

                AnimatorItem.Scale.BottomRight -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = target!!.measuredHeight.toFloat()
                }

                AnimatorItem.Scale.LeftCenter -> {
                    targetPivotX = 0f
                    targetPivotY = target!!.measuredHeight.toFloat() / 2f
                }

                AnimatorItem.Scale.RightCenter -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = target!!.measuredHeight.toFloat() / 2f
                }

                AnimatorItem.Scroll.Top -> {
                    targetPivotX = target!!.measuredWidth / 2f
                    targetPivotY = 0f
                    startScrollX = 0
                    startScrollY = target!!.measuredHeight
                }

                AnimatorItem.Scroll.Bottom -> {
                    targetPivotX = target!!.measuredWidth / 2f
                    targetPivotY = target!!.measuredHeight.toFloat()
                    startScrollX = 0
                    startScrollY = -target!!.measuredHeight
                }

                AnimatorItem.Scroll.BottomLeft -> {
                    targetPivotX = 0f
                    targetPivotY = target!!.measuredHeight.toFloat()
                    startScrollX = target!!.measuredWidth
                    startScrollY = -target!!.measuredHeight
                }

                AnimatorItem.Scroll.BottomRight -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = target!!.measuredHeight.toFloat()
                    startScrollX = -target!!.measuredWidth
                    startScrollY = -target!!.measuredHeight
                }

                AnimatorItem.Scroll.Left -> {
                    targetPivotX = 0f
                    targetPivotY = target!!.measuredHeight.toFloat() / 2f
                    startScrollX = target!!.measuredWidth
                    startScrollY = 0
                }

                AnimatorItem.Scroll.Right -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = target!!.measuredHeight / 2f
                    startScrollX = -target!!.measuredWidth
                    startScrollY = 0
                }

                AnimatorItem.Scroll.TopLeft -> {
                    targetPivotX = 0f
                    targetPivotY = 0f
                    startScrollX = target!!.measuredWidth
                    startScrollY = target!!.measuredHeight
                }

                AnimatorItem.Scroll.TopRight -> {
                    targetPivotX = target!!.measuredWidth.toFloat()
                    targetPivotY = 0f
                    startScrollX = -target!!.measuredWidth
                    startScrollY = target!!.measuredHeight
                }
            }
        }
    }

    protected open fun setShowAnimator(item: AnimatorItem, animator: AnimatorSet) {
        when (item) {
            AnimatorItem.Alpha -> {
                animator.playTogether(
                    ObjectAnimator.ofFloat(target!!, View.ALPHA, target!!.alpha, 1f)
                )
            }

            is AnimatorItem.Translate -> {
                target!!.translationX = targetTranslateX
                target!!.translationY = targetTranslateY
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.TRANSLATION_X, target!!.translationX,
                        initTranslateX
                    )
                )
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.TRANSLATION_Y, target!!.translationY,
                        initTranslateY
                    )
                )
            }

            is AnimatorItem.Scale -> {
                target!!.pivotX = targetPivotX
                target!!.pivotY = targetPivotY
                target!!.scaleX = scaleFactor
                target!!.scaleY = scaleFactor
                animator.playTogether(
                    ObjectAnimator.ofFloat(target!!, View.SCALE_X, target!!.scaleX, 1f)
                )
                animator.playTogether(
                    ObjectAnimator.ofFloat(target!!, View.SCALE_Y, target!!.scaleY, 1f)
                )
            }

            is AnimatorItem.Scroll -> {
                target!!.pivotX = targetPivotX
                target!!.pivotY = targetPivotY
                animator.playTogether(
                    ValueAnimator.ofInt(max(startScrollX, startScrollY), 0).apply {
                        addUpdateListener { animation ->
                            target!!.scrollTo(
                                intEvaluator.evaluate(
                                    animation.animatedFraction, startScrollX, 0
                                ),
                                intEvaluator.evaluate(
                                    animation.animatedFraction, startScrollY, 0
                                )
                            )
                        }
                    })
            }
        }
    }

    protected open fun setDismissAnimator(item: AnimatorItem, animator: AnimatorSet) {
        when (item) {
            AnimatorItem.Alpha -> {
                animator.playTogether(
                    ObjectAnimator.ofFloat(target!!, View.ALPHA, target!!.alpha, 0f)
                )
            }

            is AnimatorItem.Translate -> {
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.TRANSLATION_X, target!!.translationX,
                        targetTranslateX
                    )
                )
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.TRANSLATION_Y, target!!.translationY,
                        targetTranslateY
                    )
                )
            }

            is AnimatorItem.Scale -> {
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.SCALE_X, target!!.scaleX, scaleFactor
                    )
                )
                animator.playTogether(
                    ObjectAnimator.ofFloat(
                        target!!, View.SCALE_Y, target!!.scaleY, scaleFactor
                    )
                )
            }

            is AnimatorItem.Scroll -> {
                animator.playTogether(
                    ValueAnimator.ofInt(max(startScrollX, startScrollY), 0).apply {
                        addUpdateListener { animation ->
                            target!!.scrollTo(
                                intEvaluator.evaluate(
                                    animation.animatedFraction, 0, startScrollX
                                ),
                                intEvaluator.evaluate(
                                    animation.animatedFraction, 0, startScrollY
                                )
                            )
                        }
                    })
            }
        }
    }

    fun clearAnimatorItems() {
        animatorItems.clear()
    }

    fun addAnimatorItem(item: AnimatorItem) {
        animatorItems.add(item)
    }

    fun setAnimatorItems(items: List<AnimatorItem>) {
        animatorItems.clear()
        animatorItems.addAll(items)
    }
}