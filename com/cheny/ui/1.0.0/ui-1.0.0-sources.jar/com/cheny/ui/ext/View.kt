package com.cheny.ui.ext

import android.app.Activity
import android.graphics.Point
import android.graphics.PointF
import android.graphics.Rect
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.annotation.AnimRes
import androidx.annotation.LayoutRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isGone
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.core.view.marginBottom
import androidx.core.view.marginEnd
import androidx.core.view.marginStart
import androidx.core.view.marginTop
import androidx.core.view.setMargins
import com.cheny.kit.ext.activity
import com.cheny.kit.ext.cast
import com.cheny.kit.ext.castOrNull

val View.activity: Activity?
    get() = context.activity

val View.linearLayoutParams: LinearLayout.LayoutParams
    get() {
        return layoutParams.cast()
    }

val View.frameLayoutParams: FrameLayout.LayoutParams
    get() {
        return layoutParams.cast()
    }

val View.relativeLayoutParams: RelativeLayout.LayoutParams
    get() {
        return layoutParams.cast()
    }

val View.constraintLayoutParams: ConstraintLayout.LayoutParams
    get() {
        return layoutParams.cast()
    }

fun View.runOnUiThread(runnable: () -> Unit) {
    context.activity?.runOnUiThread(runnable)
}

fun View.gone() = run { isGone = true }

fun View.visible() = run { isVisible = true }

fun View.invisible() = run { isInvisible = true }

inline fun <T : View> T.afterMeasured(crossinline predicate: () -> Unit) {
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() {
            if (measuredWidth > 0 && measuredHeight > 0) {
                viewTreeObserver.removeOnGlobalLayoutListener(this)
                predicate.invoke()
            }
        }
    })
}

fun View.setWidth(width: Int) {
    var lp = layoutParams
    if (lp == null) {
        lp = ViewGroup.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT)
    } else {
        lp.width = width
    }
    layoutParams = lp
}

fun View.setHeight(height: Int) {
    var lp = layoutParams
    if (lp == null) {
        lp = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, height)
    } else {
        lp.height = height
    }
    layoutParams = lp
}

fun View.setSize(width: Int, height: Int) {
    var lp = layoutParams
    if (lp == null) {
        lp = ViewGroup.LayoutParams(width, height)
    } else {
        lp.width = width
        lp.height = height
    }
    layoutParams = lp
}

fun View.getLocalVisibleRect(): Rect {
    val rect = Rect()
    getLocalVisibleRect(rect)
    return rect
}

fun View.getGlobalVisibleRect(): Rect {
    val rect = Rect()
    getGlobalVisibleRect(rect)
    return rect
}

fun View.getLocationOnScreen(): Point {
    val location = IntArray(2)
    getLocationOnScreen(location)
    return Point(location[0], location[1])
}

fun View.getLocationInWindow(): Point {
    val location = IntArray(2)
    getLocationInWindow(location)
    return Point(location[0], location[1])
}

fun View.setPaddingStart(paddingStart: Int) {
    setPaddingRelative(paddingStart, paddingTop, paddingRight, paddingBottom)
}

fun View.setPaddingTop(paddingTop: Int) {
    setPaddingRelative(paddingLeft, paddingTop, paddingRight, paddingBottom)
}

fun View.setPaddingEnd(paddingEnd: Int) {
    setPaddingRelative(paddingLeft, paddingTop, paddingEnd, paddingBottom)
}

fun View.setPaddingBottom(paddingBottom: Int) {
    setPaddingRelative(paddingLeft, paddingTop, paddingRight, paddingBottom)
}

fun View.setPaddingHorizontal(padding: Int) {
    setPaddingRelative(padding, paddingTop, padding, paddingBottom)
}

fun View.setPaddingVertical(padding: Int) {
    setPaddingRelative(paddingStart, padding, paddingEnd, padding)
}

fun View.setMargins(margins: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(margins)
    layoutParams = lp
}

fun View.setStartMargin(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(margin, marginTop, marginEnd, marginBottom)
    layoutParams = lp
}

fun View.setTopMargin(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(marginStart, margin, marginEnd, marginBottom)
    layoutParams = lp
}

fun View.setEndMargin(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(marginStart, marginTop, margin, marginBottom)
    layoutParams = lp
}

fun View.setBottomMargin(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(marginStart, marginTop, marginEnd, margin)
    layoutParams = lp
}

fun View.setMarginHorizontal(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(margin, marginTop, margin, marginBottom)
    layoutParams = lp
}

fun View.setMarginVertical(margin: Int) {
    val lp = layoutParams as ViewGroup.MarginLayoutParams
    lp.setMargins(marginStart, margin, marginEnd, margin)
    layoutParams = lp
}

fun View.startAnimation(@AnimRes animRes: Int) {
    startAnimation(AnimationUtils.loadAnimation(context, animRes))
}

fun ViewGroup.inflater(
    @LayoutRes layoutId: Int,
    root: ViewGroup = this,
    attachToRoot: Boolean = false
): View {
    return LayoutInflater.from(context).inflate(layoutId, root, attachToRoot)
}

/**
 * 判断View在屏幕中的坐标系是否包含某个点
 */
fun View.containsPointOnScreen(point: PointF): Boolean {
    return containsPointOnScreen(point.x, point.y)
}

/**
 * 判断View在屏幕中的坐标系是否包含某个点
 */
fun View.containsPointOnScreen(x: Float, y: Float): Boolean {
    val location = intArrayOf(0, 0)
    getLocationInWindow(location)
    val left = location[0]
    val top = location[1]
    val bottom = top + height
    val right = left + width
    return x > left && x < right && y > top && y < bottom
}

/**
 * 设置防重复点击的点击事件
 *
 * @param interval 点击间隔时间，默认500毫秒
 * @param listener 只有在间隔时间外的点击才会触发的回调
 */
fun View.singleClick(interval: Long = 500, listener: ((View) -> Unit)?) {
    if (listener == null) {
        setOnClickListener(null)
        return
    }
    singleClick(interval) { _, _ -> listener(this) }
}

/**
 * 防重复点击的 OnClickListener
 * @param interval 点击间隔时间，默认500毫秒
 * @param listener 每次点击都会回调，可以通过isFast判断是否是快速点击
 */
fun View.singleClick(
    interval: Long = 500,
    listener: ((view: View, isFast: Boolean) -> Unit)?
) {
    if (listener == null) {
        setOnClickListener(null)
        return
    }
    setOnClickListener {
        val tagKey = Int.MAX_VALUE - 1001
        val lastTimestamp = this.getTag(tagKey).castOrNull<Long>() ?: 0
        val currentTime = SystemClock.elapsedRealtime()
        if (currentTime - lastTimestamp >= interval) {
            this.setTag(tagKey, currentTime)
            listener(this, false)
        } else {
            listener(this, true)
        }
    }
}