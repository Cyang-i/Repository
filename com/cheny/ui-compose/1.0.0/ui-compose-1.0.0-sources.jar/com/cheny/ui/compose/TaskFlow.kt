package com.cheny.ui.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.cheny.kit.FlowTask

@Composable
fun rememberFlowTask(): FlowTask {
    val scope = rememberCoroutineScope()
    val flowTask = remember { FlowTask(scope) }

    DisposableEffect(Unit) {
        onDispose { flowTask.stop() }
    }
    return flowTask
}