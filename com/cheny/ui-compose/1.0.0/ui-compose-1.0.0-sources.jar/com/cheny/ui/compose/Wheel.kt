package com.cheny.ui.compose

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

@Immutable
class WheelScope<T>(
    val itemIndex: Int,
    val item: T,
    val itemSelected: Boolean,
    val offsetFraction: Float
)

@Stable
class WheelState {
    internal val scrollOffset = Animatable(0f)

    internal var internalItemsCount by mutableIntStateOf(0)
    internal var internalIsLooping by mutableStateOf(false)
    internal var internalItemHeightPx by mutableFloatStateOf(0f)
    internal var internalVisibleItemsCount by mutableIntStateOf(5)

    val isAnimationRunning: Boolean by derivedStateOf { scrollOffset.isRunning }
    var isScrolling by mutableStateOf(false)
        internal set

    val currentSelection: Int by derivedStateOf {
        val count = internalItemsCount
        val height = internalItemHeightPx
        if (count == 0 || height <= 0f) return@derivedStateOf 0
        val rawIndex = floor((scrollOffset.value / height) + 0.5f).toInt()
        (rawIndex % count + count) % count
    }

    internal fun updateConstraints() {
        if (internalIsLooping || internalItemsCount <= 0 || internalItemHeightPx <= 0f) {
            scrollOffset.updateBounds(null, null)
        } else {
            val maxBound = (internalItemsCount - 1) * internalItemHeightPx
            scrollOffset.updateBounds(0f, maxBound)
        }
    }

    internal suspend fun settle(velocity: Float, decay: DecayAnimationSpec<Float>) {
        val count = internalItemsCount
        val height = internalItemHeightPx
        if (count <= 0 || height <= 0f) return

        if (abs(velocity) > 500f) {
            scrollOffset.animateDecay(-velocity, decay)
        }

        val targetValue = floor((scrollOffset.value / height) + 0.5f).toInt() * height
        val safeTarget = if (!internalIsLooping) {
            targetValue.coerceIn(0f, (count - 1) * height)
        } else {
            targetValue
        }

        scrollOffset.animateTo(
            targetValue = safeTarget,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow
            )
        )

        if (internalIsLooping) {
            val totalH = count * height
            val normalized = (scrollOffset.value % totalH + totalH) % totalH
            scrollOffset.snapTo(normalized)
        }
        isScrolling = false
    }

    suspend fun scrollToIndex(index: Int, animated: Boolean = true) {
        val count = internalItemsCount
        val height = internalItemHeightPx
        if (count <= 0 || height <= 0f) return

        val realTargetIndex = (index % count + count) % count
        val currentRawIndex = floor((scrollOffset.value / height) + 0.5f).toInt()
        val currentRealIndex = (currentRawIndex % count + count) % count

        var diff = realTargetIndex - currentRealIndex
        if (internalIsLooping) {
            if (diff > count / 2) diff -= count
            else if (diff < -count / 2) diff += count
        }

        var targetOffset = (currentRawIndex + diff) * height
        if (!internalIsLooping) {
            targetOffset = targetOffset.coerceIn(0f, (count - 1) * height)
        }

        isScrolling = true
        if (animated) {
            scrollOffset.animateTo(targetOffset, spring(stiffness = Spring.StiffnessLow))
        } else {
            scrollOffset.snapTo(targetOffset)
        }
        isScrolling = isAnimationRunning
    }
}

@Composable
fun rememberWheelState(): WheelState = remember { WheelState() }

@Composable
fun <T> Wheel(
    items: List<T>,
    state: WheelState,
    modifier: Modifier = Modifier,
    isLooping: Boolean = true,
    visibleItemsCount: Int = 5,
    wheelRadius: Dp = 120.dp,
    itemHeight: Dp = 50.dp,
    decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
    offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
    onItemSelected: (Int) -> Unit = {},
    content: @Composable WheelScope<T>.() -> Unit
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val itemHeightPx = with(density) { itemHeight.toPx() }
    val radiusPx = with(density) { wheelRadius.toPx() }

    state.internalItemsCount = items.size
    state.internalIsLooping = isLooping
    state.internalItemHeightPx = itemHeightPx
    state.internalVisibleItemsCount = visibleItemsCount
    state.updateConstraints()

    LaunchedEffect(state.currentSelection) {
        onItemSelected(state.currentSelection)
    }

    Box(
        modifier = modifier
            .height(itemHeight * visibleItemsCount)
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { delta ->
                    state.isScrolling = true
                    scope.launch { state.scrollOffset.snapTo(state.scrollOffset.value - delta) }
                },
                onDragStopped = { velocity ->
                    scope.launch { state.settle(velocity, decay) }
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        val currentScrollValue = state.scrollOffset.value
        val centerPointIndex = if (itemHeightPx > 0) currentScrollValue / itemHeightPx else 0f
        val range = (visibleItemsCount / 2) + 1
        val startRenderIndex = floor(centerPointIndex).toInt() - range
        val endRenderIndex = ceil(centerPointIndex).toInt() + range

        for (i in startRenderIndex..endRenderIndex) {
            val realIndex = if (isLooping) {
                (i % items.size + items.size) % items.size
            } else {
                if (i < 0 || i >= items.size) continue else i
            }

            val itemData = items[realIndex]
            val offsetFraction = i - centerPointIndex
            val angle = (offsetFraction * itemHeightPx) / radiusPx
            if (angle !in -PI / 2f..PI / 2f) continue

            Box(
                modifier = Modifier.fillMaxWidth().height(itemHeight).graphicsLayer {
                    rotationX = -(angle * 180f / PI).toFloat()
                    translationY = (radiusPx * sin(angle))
                    translationX = with(density) { offsetX(offsetFraction).toPx() }
                    val limit = visibleItemsCount / 2f
                    val absOffset = abs(offsetFraction)
                    val fadeArea = 0.5f
                    val boundaryAlpha = if (absOffset <= limit - fadeArea) 1f
                    else (1f - (absOffset - (limit - fadeArea)) / fadeArea).coerceIn(0f, 1f)
                    alpha = boundaryAlpha * cos(angle).coerceIn(0f, 1f)
                    scaleX = cos(angle).coerceIn(0.5f, 1f); scaleY = scaleX
                    cameraDistance = 14f * density.density
                },
                contentAlignment = Alignment.Center
            ) {
                content(
                    WheelScope(
                        realIndex, itemData, i == centerPointIndex.roundToInt(), offsetFraction
                    )
                )
            }
        }
    }
}