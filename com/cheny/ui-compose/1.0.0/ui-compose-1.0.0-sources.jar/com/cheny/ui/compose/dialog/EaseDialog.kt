package com.cheny.ui.compose.dialog

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import com.cheny.ui.compose.ext.toColor

/**
 * 带动画的全屏显示Dialog，[contentAlignment]为[Alignment.Center]、[Alignment.BottomCenter]、
 * [Alignment.TopCenter]默认带有动画
 *
 * @param modifier [Modifier]
 * @param contentAlignment [content]的显示位置
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param isAnimateEnable 是否启用动画
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun ModalDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    isAnimateEnable: Boolean = true,
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    when (contentAlignment) {
        Alignment.TopCenter -> {
            TopAnimateDialog(
                dialogState = dialogState,
                modifier = modifier,
                dismissOnBackPress = dismissOnBackPress,
                dismissOnClickOutside = dismissOnClickOutside,
                backgroundColor = backgroundColor,
                duration = duration,
                dismissDelay = dismissDelay,
                isInterceptBackEvent = isInterceptBackEvent,
                onDismiss = onDismiss,
                content = content
            )
        }
        Alignment.Center -> {
            CenterAnimateDialog(
                dialogState = dialogState,
                modifier = modifier,
                dismissOnBackPress = dismissOnBackPress,
                dismissOnClickOutside = dismissOnClickOutside,
                backgroundColor = backgroundColor,
                duration = duration,
                dismissDelay = dismissDelay,
                isInterceptBackEvent = isInterceptBackEvent,
                onDismiss = onDismiss,
                content = content
            )
        }
        Alignment.BottomCenter -> {
            BottomAnimateDialog(
                dialogState = dialogState,
                modifier = modifier,
                dismissOnBackPress = dismissOnBackPress,
                dismissOnClickOutside = dismissOnClickOutside,
                backgroundColor = backgroundColor,
                duration = duration,
                dismissDelay = dismissDelay,
                isInterceptBackEvent = isInterceptBackEvent,
                onDismiss = onDismiss,
                content = content
            )
        }
        else -> {
            AnimatableDialog(
                dialogState = dialogState,
                modifier = modifier,
                contentAlignment = contentAlignment,
                dismissOnBackPress = dismissOnBackPress,
                dismissOnClickOutside = dismissOnClickOutside,
                backgroundColor = backgroundColor,
                duration = duration,
                dismissDelay = dismissDelay,
                isInterceptBackEvent = isInterceptBackEvent,
                onDismiss = onDismiss,
                content = content
            )
        }
    }
}

/**
 * 带动画的全屏显示Dialog
 *
 * @param modifier [Modifier]
 * @param contentAlignment [content]的显示位置
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param isAnimateEnable 是否启用动画
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun AnimatableDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    isAnimateEnable: Boolean = true,
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    LaunchedEffect(dialogState.targetVisible) {
        if (dialogState.targetVisible) {
            dialogState.currentVisible = true
        }
    }
    val color by animateColorAsState(
        targetValue = if (dialogState.targetVisible) backgroundColor else Color.Transparent,
        animationSpec = tween(duration),
        finishedListener = {
            if (!dialogState.targetVisible) {
                dialogState.currentVisible = false
            }
        }
    )
    val alpha by animateFloatAsState(
        targetValue = if (dialogState.targetVisible) 1f else 0f,
        animationSpec = if (isAnimateEnable) tween(duration) else tween(0)
    )
    if (!dialogState.currentVisible) return
    FullDialog(
        modifier = modifier,
        contentAlignment = contentAlignment,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = color,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = { if (onDismiss == null) dialogState.dismiss() else onDismiss() },
        content = {
            if (isAnimateEnable) {
                Box(Modifier.alpha(alpha)) { content() }
            } else {
                content()
            }
        },
    )
}

@Composable
private fun TopAnimateDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    AnimatableDialog(
        modifier = modifier,
        contentAlignment = Alignment.TopCenter,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = false
    ) {
        AnimatedVisibility(
            visibleState = visibleState,
            enter = slideInVertically(
                animationSpec = tween(duration),
                initialOffsetY = { -it }
            ) + fadeIn(animationSpec = tween(duration)),
            exit = slideOutVertically(
                animationSpec = tween(duration),
                targetOffsetY = { -it }
            ) + fadeOut(animationSpec = tween(duration))
        ) {
            content()
        }
    }
}

@Composable
private fun CenterAnimateDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    AnimatableDialog(
        modifier = modifier,
        contentAlignment = Alignment.Center,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = true
    ) {
        content()
    }
}

@Composable
private fun BottomAnimateDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    AnimatableDialog(
        modifier = modifier,
        contentAlignment = Alignment.BottomCenter,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = false
    ) {
        AnimatedVisibility(
            visibleState = visibleState,
            enter = slideInVertically(
                animationSpec = tween(duration),
                initialOffsetY = { it }
            ) + fadeIn(animationSpec = tween(duration)),
            exit = slideOutVertically(
                animationSpec = tween(duration),
                targetOffsetY = { it }
            ) + fadeOut(animationSpec = tween(duration))
        ) {
            content()
        }
    }
}

@Stable
class DialogState(initial: Boolean) {
    var isVisible: Boolean
        get() = currentVisible
        set(value) {
            targetVisible = value
        }
    internal var currentVisible by mutableStateOf(initial)
    internal var targetVisible by mutableStateOf(initial)
        private set

    fun show() {
        targetVisible = true
    }

    fun dismiss() {
        targetVisible = false
    }
}

@Composable
fun rememberDialogState(initial: Boolean = true): DialogState {
    return remember { DialogState(initial) }
}