package com.cheny.ui.compose.ext

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.toColorInt

fun String.toColor(): Color {
    return Color(toColorInt())
}

val Color.hexString: String
    get() {
        return if (alpha != 1f) {
            String.format("#%08X", this.toArgb())
        } else {
            String.format("#%06X", this.toArgb() and 0x00FFFFFF)
        }
    }