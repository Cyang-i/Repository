package com.cheny.ui.compose.dialog

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.cheny.ui.compose.ext.toColor
import kotlinx.coroutines.delay

/**
 * 全屏显示的Dialog
 *
 * @param modifier [Modifier]
 * @param contentAlignment [content]的显示位置
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun FullDialog(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    dismissDelay?.let {
        LaunchedEffect(Unit) {
            delay(dismissDelay)
            onDismiss()
        }
    }
    BaseDialog {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(backgroundColor)
                .then(modifier)
                .clickable(
                    enabled = dismissOnClickOutside,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = contentAlignment
        ) {
            //防止点击Content触发onDismiss
            Box(
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
            ) {
                content()
            }
        }
        if (isInterceptBackEvent) {
            BackHandler {
                if (dismissOnBackPress) {
                    onDismiss()
                }
            }
        }
    }
}