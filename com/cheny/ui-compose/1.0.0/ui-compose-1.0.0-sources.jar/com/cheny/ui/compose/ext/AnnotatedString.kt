package com.cheny.ui.compose.ext

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString

fun String.toAnnotatedString(): AnnotatedString {
    return AnnotatedString(this)
}

fun AnnotatedString.withStyle(target: String, style: SpanStyle): AnnotatedString {
    val startIndex = this.text.indexOf(target)
    if (startIndex == -1) return this

    return buildAnnotatedString {
        append(this@withStyle)
        addStyle(
            style = style,
            start = startIndex,
            end = startIndex + target.length
        )
    }
}

fun AnnotatedString.withClickable(
    target: String,
    linkStyles: TextLinkStyles,
    onClick: (LinkAnnotation) -> Unit = {}
): AnnotatedString {
    val startIndex = this.text.indexOf(target)
    if (startIndex == -1) return this

    return buildAnnotatedString {
        append(this@withClickable)
        addLink(
            clickable = LinkAnnotation.Clickable(
                tag = target,
                styles = linkStyles,
                linkInteractionListener = { onClick(it) }
            ),
            start = startIndex,
            end = startIndex + target.length
        )
    }
}